/* Problem1.java - fill in the main method as directed. */

/* Replace this comment with your name, uni and anything 
 * you need us to know about the program */

public class Problem1 {
  
  public static <AnyType extends Comparable<AnyType>>  AnyType findMax(AnyType[] arr) {
    int maxIndex = 0;
    for (int i = 1; i < arr.length; i++)
      if ( arr[i].compareTo(arr[maxIndex]) > 0 )
         maxIndex = i;
      return arr[maxIndex];
  }
  
  
  public static final void main(String[] args) {
      Rectangle[] rects = new Rectangle[5];
      
      rects[0] = new Rectangle(1,3);
      rects[1] = new Rectangle(2,3);
      rects[2] = new Rectangle(1,4);
      rects[3] = new Rectangle(6,3);
      rects[4] = new Rectangle(1,2);
      System.out.println(findMax(rects));
      //System.out.println("Hi");
    
    //Insert your test code as directed in the assignment.
    
    
  }
  
 
}