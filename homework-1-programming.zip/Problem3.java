/* Following the specification in the README.md file, provide your 
 * Problem3.java class.
 * /
 * 
 */
import java.util.Scanner;

public class Problem3
{
    public static void main(String[] args)
    {
        Scanner in = new Scanner(System.in);
        int num = in.nextInt();
        long startTime = System.nanoTime();
        int sum = 0;
        //
        //setting up the variables for the timers
        //
        for ( int i = 0; i < 23; i ++)
        {
            for ( int j = 0; j < num ; j ++)
            {
                sum = sum + 1;
            }
        }            
        //
        //printing out the runtime
        //
        long endTime = System.nanoTime();
        long runTime = endTime - startTime;
        System.out.println("Fragment 1 runtime: " + runTime);
        
        startTime = System.nanoTime();
        sum = 0;
        //
        //resetting the start time between each fragment
        //
        for ( int i = 0; i < num ; i ++)
        {
            for ( int k = i ; k < num ; k ++)
            {
                sum = sum + 1;      
            }      
        }
        //
        //printing runtime
        //            
        endTime = System.nanoTime();
        runTime = endTime - startTime;
        System.out.println("Fragment 2 runtime: " + runTime);
        
        startTime = System.nanoTime();
        //
        //reset start time
        //
        foo(num,2);
        //
        //print out variables
        //
        endTime = System.nanoTime();
        runTime = endTime - startTime;
        System.out.println("Fragment 3 runtime: " + runTime);
        
    }
    
    public static int foo(int n, int k) 
    {
        if(n<=k)
        {
            return 1;
        }
        else
        {
            return foo(n/k,k) + 1;
        }
            
    }
}