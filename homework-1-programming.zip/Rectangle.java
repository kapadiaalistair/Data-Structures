/* Create your Rectangle.java from scratch here.  Make sure 
 * you include all the methods indicated in the assignment,
 * even if it appears that you're not using them in the main 
 * of the tester.  Remember, this needs to extend Comparable. */

/* Replace this comment with your name, uni and anything 
 * you need us to know about the program */

public class Rectangle implements Comparable<Rectangle>{
    private double w;
    private double l;
    public int compareTo(Rectangle a)
    {
        if(this.perimeter()<a.perimeter())
        {
            return -1;
        }
        if(this.perimeter()>a.perimeter())
        {
            return 1;
        }
        else
        {
            return 0;
        }
    }
    public String toString()
    {
        return ("Perimeter: " + this.perimeter() + " Length: " + this.getLength() + " Width: " + this.getWidth());
    }
    public Rectangle(double width, double length)
    {
        w = width;
        l = length;
    }
    public double perimeter()
    {
        return w*2+l*2;
    }
    public double getWidth()
    {
        return w;
    }
    public double getLength()
    {
        return l;
    }
}