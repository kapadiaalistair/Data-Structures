# Student README file

Problem 1: Created Rectangle class. And made toString method to print out Rectangles.
Problem 2: You have to edit the main method to state what you are searching for as well as create the array you are searching in. 
The main method also prints out the array created in main method.
Problem 3: Must enter the value of n in the terminal after running the program. And it prints out the runtime of each fragment in order.