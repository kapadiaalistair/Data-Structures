/* Following the specification in the README.md file, provide your 
 * Problem2.java class.
 * /
*/
import java.util.Arrays;
public class Problem2
{
/*
    public static void main(String[] args)
    {
        //Create array of rectangles to search through
        Rectangle[] rects = new Rectangle[5];
        rects[0] = new Rectangle(1,3);
        rects[1] = new Rectangle(2,3);
        rects[2] = new Rectangle(1,4);
        rects[3] = new Rectangle(6,3);
        rects[4] = new Rectangle(1,2);
        
        //Sort the array
        Arrays.sort(rects);
        
        //Create the rectangle you are searching for
        Rectangle x = new Rectangle(1,2);
        for(int z = 0; z<5; z++)
        {
            System.out.println(rects[z]);
        }
        //Run the search method
        System.out.println("Index is: " + binarySearch(rects,x));      
    }
*/

public static void main(String[] args){

       Rectangle[] arr = new Rectangle[4];
       arr[0] = new Rectangle(3, 60); // fourth
       arr[1] = new Rectangle(2,4); // second
       arr[2] = new Rectangle(9,1); // third
       arr[3] = new Rectangle(1,1); // first

       Arrays.sort(arr);

       // First object in array, should print 0/1 depending on indexing
       System.out.println(binarySearch(arr, new Rectangle(1,1)));

       // Last object in array, should print 3/4 depending on indexing
       System.out.println(binarySearch(arr, new Rectangle(3, 60)));

// Array where object doesn't exist
       // Should return -1
       System.out.println(binarySearch(arr, new Rectangle(400,400)));



}

    public static <AnyType extends Comparable<AnyType>>       
     int binarySearch(AnyType[] a, AnyType x)
    {
        int start = 0;
        int end = a.length-1;
        return binaryHelp(a,x,start, end);
    }
    public static <AnyType extends Comparable<AnyType>> int binaryHelp(AnyType[] f, AnyType d, int j, int k)
    {
        int mid = (j + k)/2;
        if((k-j)>=0)
        {
            if(f[mid].compareTo(d)==0)
            {
                return mid;
            }
            if(f[mid].compareTo(d)>0)
            {
                return binaryHelp(f,d,j,mid-1);
            }
            else{
                return binaryHelp(f,d,mid+1,k);
            }
        }
        return -1;
        
    }
    
}
