/* Following the specification in the README.md file, provide your 
 * MyStack class.
 */
import java.util.*;
public class MyStack<AnyType>{
    private LinkedList<AnyType> data;
    public MyStack()
    {
        data = new LinkedList<AnyType>();
    }
    public void push(AnyType x)
    {
        data.add(x);
    }
    public AnyType pop()
    {
        if(data.size() > 0)
        {
            return data.removeLast();
        }
        return null;
    }
    public AnyType peek()
    {
        if(data.size()>0)
        {
            return data.getLast();
        }
        return null;
    }
    public boolean isEmpty()
    {
        if(data.size() == 0)
        {
            return true;
        }
        return false;
    }
    public int size()
    {
        return data.size();
    }

}

