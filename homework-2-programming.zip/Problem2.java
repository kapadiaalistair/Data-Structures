/* Following the specification in the README.md file, provide your 
 * Problem2 class.
 */

public class Problem2{
    public static void main(String[] args)
    {
        TwoStackQueueTester.main(args);
    }
}