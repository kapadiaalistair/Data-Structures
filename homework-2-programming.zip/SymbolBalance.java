/* Following the specification in the README.md file, provide your 
 * SymbolBalance class.
 */
import java.io.File; 
import java.io.FileNotFoundException; 
import java.util.*;
public class SymbolBalance{
    public static void main(String[] args) throws FileNotFoundException
    {
        File file = new File(args[0]);
        Scanner sc = new Scanner(file);
        sc.useDelimiter("");     
        System.out.println( check(sc));
    }
    public static String check(Scanner sc)
    {
        int linecounter = 1;
        MyStack<Character> match = new MyStack<Character>();
        char c;
        char temp;
        int quoteline  = -1;;
        while(sc.hasNext()){
            c = sc.next().charAt(0);
            if(c == '\n')
            {
                linecounter++;
            }
            /*
             * 
             * handles comments
             * 
             */
            else if(c == '/')
            {
                c = sc.next().charAt(0);
                if(c == '/')
                {
                    sc.nextLine();
                }
                else if(c == '*')
                {
                    if(match.isEmpty() || match.peek() != '*')
                    {
                        match.push(c);
                    }
                }
            }
            /*
             * 
             * if we are in comment block
             * 
             */
            else if(c== '*')
            {
                
                if(match.peek() == '*')
                {
                    c = sc.next().charAt(0);
                    if(c == '/')
                    {
                        match.pop();
                        System.out.println("end comm block");
                    }
                }
            }
            /*
             * 
             * if char is a quote, either begin quote by pushing or end quote by popping
             * 
             */
            else if(c == '"')
            {
                if(!match.isEmpty() && match.peek() == '"')
                {
                    match.pop();
                }
                else if(match.isEmpty() || match.peek() != '*')
                {
                    quoteline = linecounter;
                    match.push(c);
                }
            }
            /*
             * 
             * if we are in single quotation
             * 
             */
            else if(c== '\'')
            {
                if(!match.isEmpty() || match.peek() == '\'')
                {
                    match.pop();
                }
                else
                {
                    match.push(c);
                }
            /*
             * 
             * opening brackets are pushed unless we are in quotes, comment block, or single quotes
             * 
             */
            }
            else if(c == '[' || c == '(' || c == '{')
            {
                if(match.isEmpty() || (quoteline !=linecounter && match.peek()!= '"' && match.peek() != '*' && match.peek() != '\''))
                {
                    match.push(c);
                }
            }
            /*
             * 
             * closing 3 kinds of brackets unless again we are in quotes, comment block, or single quotes
             * 
             */
            else if(c == ']')
            {
                if(quoteline!=linecounter &&match.peek()!= '"' && match.peek() != '*' && match.peek() != '\'')
                {
                    if(match.size() == 0)
                    {
                        return (linecounter + ": Empty");
                    }
                    temp = match.pop();
                    if(temp != '[')
                    {
                        return (linecounter + ": " + c + ", " + temp);
                    }
                }
            }
            else if(c == ')')
            {
                if(quoteline != linecounter && match.peek()!= '"' && match.peek() != '*' && match.peek() != '\'')
                {
                    if(match.size() == 0)
                    {
                        return (linecounter + ": Empty");
                    }
                    temp = match.pop();
                    if(temp != '(')
                    {
                        return (linecounter + ": " + c + ", " + temp);
                    }
                }
            }
            else if(c == '}')
            {
                if(match.isEmpty() || (quoteline != linecounter&& match.peek()!= '"' && match.peek() != '*' && match.peek() != '\''))
                {
                    if(match.isEmpty())
                    {
                        return (linecounter + ": Empty");
                    }
                    temp = match.pop();
                    if(temp != '{')
                    {
                        return (linecounter + ": " + c + ", " + temp);
                    }
                }
            }
        }
        /*
         * 
         * Final case: if stack isnt empty, return error. otherwise return correct.
         * 
         */
        if(match.size() !=0)
        {
            return ("Nonempty Stack: " + match.peek() + ", " + match.size());
        }
        else
        {
            return ("Correct");
        }
        
    }
    
}
//{ }’s, ( )'s, [ ]'s, " "’s, and /* */
//Ignore things in comment blocks, comment lines, strings, things in single quotes


