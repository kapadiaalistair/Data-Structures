/* this is to test whether the program can deal with an imbalance of "  */
public class Test6 {
	public static void main(String[] args) {
		boolean votedForBurr = false;
		boolean jeffersonHasBeliefs = true;
		boolean burrHasBeliefs = false;
		int vote = AlexanderVote(burrHasBeliefs);
	}

	/*going to make an arbitrary value */ 
	public int AlexanderVote(boolean belief) {
		String whoAmIVotingFor = "hamilton;
		return 0;

	}
}