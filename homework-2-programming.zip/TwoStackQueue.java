/* Following the specification in the README.md file, provide your 
 * TwoStackQueue class.
 */

import java.util.*;

public class TwoStackQueue<AnyType> implements MyQueue<AnyType>{
    //instance variables
    private MyStack<AnyType> s1;
    private MyStack<AnyType> s2;
    //constructor
    public TwoStackQueue()
    {
        s1 = new MyStack<AnyType>();
        s2 = new MyStack<AnyType>();
    }
    
    // Performs the enqueue operation
    public void enqueue(AnyType x)
    {
           s1.push(x);
    }

    // Performs the dequeue operation. For this assignment, if you
    // attempt to dequeue an already empty queue, you should return
    // null
    public AnyType dequeue()
    {
        //If s2 is empty, push all items from s1 to s2. This ensures the queue will be first in first out. 
        if(s2.isEmpty())
        {
            while(!s1.isEmpty())
            {
                s2.push(s1.pop());
            }
        }
        return s2.pop();
    }

    // Checks if the Queue is empty
    public boolean isEmpty()
    {
        if(s1.isEmpty() && s2.isEmpty())
        {
            return true;
        }
        return false;
    }

    // Returns the number of elements currently in the queue
    public int size()
    {
        return (s1.size() + s2.size());
    }
}