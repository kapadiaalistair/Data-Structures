import java.util.*;
import java.io.*;

public class AutomationGrader {

	private static HashSet<String> errorLog = new HashSet<>();

	private static void checkIsEmpty(MyStack stack, boolean value) {
		if (stack.isEmpty() == value) {
			System.out.println("Check isEmpty(): OK");
		}
		else {
			String error = "Check isEmpty(): Fail";
			System.out.println(error);
			errorLog.add(error);
		}
	}

	private static void checkSize(MyStack stack, int size) {
		if (stack.size() == size) {
			System.out.println("Check size(): OK");
		}
		else {
			String error = "Check size(): Fail";
			System.out.println(error);
			errorLog.add(error);
		}
	}

	private static void checkPop(int value, int actualValue) {
		if (value == actualValue) {
			System.out.println("Check Pop: OK");
		}
		else {
			String error = "Check Pop: Fail";
			System.out.println(error);
			errorLog.add(error);
		}
	}

	public static void checkStringPop(String value, String actualValue) {

		if (value.equals(actualValue))
			System.out.println("Check Pop: OK");
		else {
			String error = "Check Pop: Fail";
			System.out.println(error);
			errorLog.add(error);
		}
	}

	private static void TestCase1_A(MyStack<Integer> stack, int[] integerTestInputs) {

		checkIsEmpty(stack, true);
		checkSize(stack, 0);

		for (int i = 0; i < integerTestInputs.length; i ++)
			stack.push(integerTestInputs[i]);

		checkIsEmpty(stack, false);
		checkSize(stack, integerTestInputs.length);

		for (int i = 0; i < integerTestInputs.length; i++) {
			int poppedValue = stack.pop();
			checkPop(poppedValue, integerTestInputs[integerTestInputs.length - 1 - i]);
			checkSize(stack, integerTestInputs.length - 1 - i);
		}

		checkSize(stack, 0);
		checkIsEmpty(stack, true);

	}


	private static void TestCase2_A(MyStack<String> stack, String[] stringTestInputs) {

		checkIsEmpty(stack, true);
		checkSize(stack, 0);

		for (int i = 0; i < stringTestInputs.length; i ++)
			stack.push(stringTestInputs[i]);

		checkIsEmpty(stack, false);
		checkSize(stack, stringTestInputs.length);

		for (int i = 0; i < stringTestInputs.length; i++) {
			String poppedValue = stack.pop();
			checkStringPop(poppedValue, stringTestInputs[stringTestInputs.length - 1 - i]);
			checkSize(stack, stringTestInputs.length - 1 - i);
		}

		checkSize(stack, 0);
		checkIsEmpty(stack, true);

	}


	private static void TestCase1_B(MyStack<Integer> stack, int[] integerTestInputs) {

		checkIsEmpty(stack, true);
		checkSize(stack, 0);

		for (int i = 0; i < integerTestInputs.length; i ++) {
			stack.push(integerTestInputs[i]);
			checkSize(stack, i + 1);
			checkIsEmpty(stack, false);
		}

		for (int i = 0; i < integerTestInputs.length; i ++) {
			int poppedValue = stack.pop();
			checkPop(poppedValue, integerTestInputs[integerTestInputs.length - 1 - i]);
			checkSize(stack, integerTestInputs.length - 1 - i);
			if (i != integerTestInputs.length - 1)
				checkIsEmpty(stack, false);
		}
		checkIsEmpty(stack, true);
	}


	private static void TestCase2_B(MyStack<String> stack, String[] stringTestInputs) {

		checkIsEmpty(stack, true);
		checkSize(stack, 0);

		for (int i = 0; i < stringTestInputs.length; i ++) {
			stack.push(stringTestInputs[i]);
			checkSize(stack, i + 1);
			checkIsEmpty(stack, false);
		}

		for (int i = 0; i < stringTestInputs.length; i ++) {
			String poppedValue = stack.pop();
			checkStringPop(poppedValue, stringTestInputs[stringTestInputs.length - 1 - i]);
			checkSize(stack, stringTestInputs.length - 1 - i);
			if (i != stringTestInputs.length - 1)
				checkIsEmpty(stack, false);
		}
		checkIsEmpty(stack, true);
	}


	private static void TestCase1_C() throws Exception {

		MyStack<Integer> stack = new MyStack<>();
		stack.push(3);
		checkSize(stack, 1);
		checkIsEmpty(stack, false);
		checkPop(stack.pop(), 3);

		try {
			if (stack.pop() == null)
				System.out.println("Null received on popping an empty stack: OK");
			else {
				String error = "Check Pop: Fail";
				errorLog.add(error);
				System.out.println(error);
			}

		}

		catch(Exception e) {
			System.out.println("Error thrown on popping an empty stack: OK");
		}
	}



	private static void TestCase2_C() throws Exception {

		MyStack<String> stack = new MyStack<>();
		stack.push("321");
		checkSize(stack, 1);
		checkIsEmpty(stack, false);
		checkStringPop(stack.pop(), "321");

		try {
			if (stack.pop() == null)
				System.out.println("Null received on popping an empty stack: OK");
			else {
				String error = "Check Pop: Fail";
				errorLog.add(error);
				System.out.println(error);
			}

		}

		catch(Exception e) {
			System.out.println("Error thrown on popping an empty stack: OK");
		}
	}


	private static void TestCase1_D() throws Exception {

		MyStack<Integer> stack = new MyStack<>();
		try {
			if (stack.pop() == null)
				System.out.println("Null received on popping an empty stack: OK");
			else {
				String error = "Check Pop: Fail";
				errorLog.add(error);
				System.out.println(error);
			}

		}

		catch(Exception e) {
			System.out.println("Error thrown on popping an empty stack: OK");
		}
	}


	private static void TestCase2_D() throws Exception {

		MyStack<String> stack = new MyStack<>();
		try {
			if (stack.pop() == null)
				System.out.println("Null received on popping an empty stack: OK");
			else {
				String error = "Check Pop: Fail";
				errorLog.add(error);
				System.out.println(error);
			}

		}

		catch(Exception e) {
			System.out.println("Error thrown on popping an empty stack: OK");
		}
	}


	private static void TestCase3_A(Scanner scan) {
		System.out.print("Is Push implemented in O(1) time (y/n): ");
		String response = scan.nextLine();
		if (response.equals("n")) {
			System.out.println("Fail");
			String error = "Push not implemented in O(1) time";
			errorLog.add(error);
		}

		System.out.println("Is Pop implemented in O(1) time (y/n): ");
		response = scan.nextLine();
		if (response.equals("n")) {
			System.out.println("Fail");
			String error = "Pop not implemented in O(1) time";
			errorLog.add(error);
		}

		System.out.println("Did the student use Native Java Push/Pop Methods (y/n): ");
		response = scan.nextLine();
		if (response.equals("y")) {
			System.out.println("Fail");
			String error = "Native Java Push/Pop Methods used";
			errorLog.add(error);
		}
	}


	private static void TestCase3_B(Scanner scan) {

		System.out.print("Does the SymbolBalance class use the MyStack object as an instance variable (y/n): ");
		String response = scan.nextLine();
		if (response.equals("n")) {
			System.out.println("Fail");
			String error = "MyStack not used";
			errorLog.add(error);
		}

		System.out.print("Does the SymbolBalance take command line arguments (y/n): ");
		response = scan.nextLine();
		if (response.equals("n")) {
			System.out.println("Fail");
			String error = "Command line arguments not used";
			errorLog.add(error);
		}


		System.out.print("Does the SymbolBalance class correctly use IO (y/n): ");
		response = scan.nextLine();
		if (response.equals("n")) {
			System.out.println("Fail");
			String error = "IO not used";
			errorLog.add(error);
		}
	}

	private static void printErrorLog() {
		System.out.println("For some reason, the automated grader crashed. Given below ");
		System.out.println("is the error log before the crash: ");

		for (String error : errorLog) {
			System.out.println(error);
		}
	}

	public static void main(String[] args) throws Exception {

		Scanner scan = new Scanner(System.in);
		int[] integerTestInputs = {-1, 0, 50, -74, 2, -100, 25};
		String[] stringTestInputs = {"This", "", " tests", "the ", "student's", " code"};

		int points = 14; 

		// Test Case 1.a (Sequential Manipulation) 
		MyStack<Integer> stack = new MyStack<>();
		TestCase1_A(stack, integerTestInputs);

		// Test Case 1.b (Alternate Manipulation)
		TestCase1_B(stack, integerTestInputs);

		// Test Case 1.c (Pop an empty stack after work is performed)
		TestCase1_C();

		// Test Case 1.d (Pop an empty stack without doing work)
		TestCase1_D();

		// Test Case 2.a (Sequential Manipulation)
		MyStack<String> string_stack = new MyStack<>();
		TestCase2_A(string_stack, stringTestInputs);

		// Test Case 2.b (Alternate Manipulation)
		TestCase2_B(string_stack, stringTestInputs);

		// Test Case 2.c (Pop an empty stack after work is performed)
		TestCase2_C();

		// Test Case 2.d (Pop an empty stack without doing work)
		TestCase2_D();

		try {

			BufferedReader br = new BufferedReader(new FileReader("MyStack.java"));
			String line;
			System.out.println("*************************************************************************************************************************");
			while((line = br.readLine()) != null) { 
				System.out.println(line);
			}
			System.out.println("*************************************************************************************************************************");

			// Test Case 3.a
			TestCase3_A(scan);

			BufferedReader newbr = new BufferedReader(new FileReader("SymbolBalance.java"));
			System.out.println("*************************************************************************************************************************");
			while((line = newbr.readLine()) != null) { 
				System.out.println(line);
			}
			System.out.println("*************************************************************************************************************************");

			// Test Case 3.b
			TestCase3_B(scan);

			System.out.println("*************************************************************************************************************************");
			System.out.println("\nGiven below is the error log:\n");
			for (String error : errorLog) {
				System.out.println(error);
			}

			System.out.println("How many points to deduct?: " );
			int deductions = scan.nextInt();
			System.out.println(String.format("AWARD THE CANDIDATE %d POINTS FOR Problem2.java and TwoStackQueue.java", points - deductions));
		}

		catch (Exception e) {
			System.out.println(e);
			printErrorLog();
		}
	}
}
