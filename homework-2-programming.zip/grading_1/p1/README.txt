##########################
Author: Ishaan Agrawal
Date: October 2018
Last Update: October 2018
##########################


How to Use the Tester:
----------------------

1. For each student:

	a. Call make

	$ make

	b. Run the Automation Tester

	$ java AutomationGrader

	c. Follow the instructions displayed by the automation script
	d. Once the AutomationGrader completes grading the student's work, run SymbolBalanceGrader.

	$ ./SymbolBalanceGrader.sh

	e. If there are 0 correct outputs, manually check the student's output file.

	f. Assign grades according to the outputs of the AutomationGrader and SymbolBalanceGrader scripts.


Test Cases
----------

In this programming project, we need to test 2 files:
	1. MyStack.java
	2. SymbolBalance.java

According to the rubric, for MyStack.java, we need to ensure that:
	1. MyStack has O(1) push ( =2 points )
	2. MyStack has O(1) pop ( =2 points )
	3. Push and pop are correctly implemented ( =1 point )
	4. Native java push and pop not used ( =2 points )

According to the rubric, for SymbolBalance.java, we need to ensure that:
	1. Test on a variety of test cases ( =16 points )
	2. Uses the stack ( =3 points )
	3. Uses command line arguments ( =2 points )
	4. Uses correct File IO ( =2 points )

So the automation grader should be able to validate all of the above points of
the rubric while remaining robust to bad student code.

Given below are the list of Test Cases for which the code for Problem 1 will
be tested on:


Test Case 1: Integer Stack
	a. Test Case 1.a (Sequential Manipulation)
		i. Check isEmpty() == true
		ii. Check size() == 0
		iii. Push all elements
		iv. Check isEmpty() == false
		v. Check size() == Num_Elements_Pushed
		vi. Pop all elements
		vii. Check size() == 0
		viii. Check isEmpty() == true
		ix. Check order of popped elements is reverse of order of
		    pushed elements.

	b. Test Case 1.b (Alternate Manipulation)
		i. Check isEmpty() == true
		ii. Check size() == 0
		iii. Push 1
		iv. Check size() == 1
		v. Check isEmpty() == false
		vi. Continue iii. to v. until all are pushed
		vii. Pop and compare element to element pushed
		viii. Check size() == NUM_ELEMENTS_PUSHED - 1
		ix. Check isEmpty() == false
		x. Continue vii. to ix. till all elements are dequeued
		xi. Check isEmpty() == true

	c. Test Case 1.c (Pop an Empty Stack after work is performed)
		i. Check isEmpty() == true
		ii. Push and pop a test variable and test their equality.
		iii. Pop the empty stack (Should be null or result in error.)

	d. Test Case 1.d (Pop an Empty Stack)
		1. Pop an empty stack (Should be null or result in error)

Test Case 2: String Stack
	a. Test Case 1.a (Sequential Manipulation)
		i. Check isEmpty() == true
		ii. Check size() == 0
		iii. Push all elements
		iv. Check isEmpty() == false
		v. Check size() == Num_Elements_Pushed
		vi. Pop all elements
		vii. Check size() == 0
		viii. Check isEmpty() == true
		ix. Check order of popped elements is reverse of order of
		    pushed elements.

	b. Test Case 1.b (Alternate Manipulation)
		i. Check isEmpty() == true
		ii. Check size() == 0
		iii. Push "1"
		iv. Check size() == 1
		v. Check isEmpty() == false
		vi. Continue iii. to v. until all are pushed
		vii. Pop and compare element to element pushed
		viii. Check size() == NUM_ELEMENTS_PUSHED - 1
		ix. Check isEmpty() == false
		x. Continue vii. to ix. till all elements are dequeued
		xi. Check isEmpty() == true

	c. Test Case 1.c (Pop an Empty Stack after work is performed)
		i. Check isEmpty() == true
		ii. Push and pop a test variable and test their equality.
		iii. Pop the empty stack (Should be null or result in error.)

	d. Test Case 1.d (Pop an Empty Stack)
		1. Dequeue an empty queue (Should be null or result in error)


Test Case 3: Manual Check
	a. Push and Pop are both O(1) operations
	b. Native Java push and pop methods not used


Test Case 4: Testing SymbolBalance on a variety of files
	a. Test1.java
	b. Test2.java
	c. Test3.java
	d. Test4.java
	e. Test5.java
	f. Test6.java
	g. MyTest1.java
	h. MyTest2.java
	i. MyTest3.java
	j. MyTest4.java
