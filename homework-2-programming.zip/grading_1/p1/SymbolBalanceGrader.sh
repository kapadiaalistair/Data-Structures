rm -f student_output.txt

java SymbolBalance TestFiles/Test1.java >> student_output.txt
java SymbolBalance TestFiles/Test2.java >> student_output.txt
java SymbolBalance TestFiles/Test3.java >> student_output.txt
java SymbolBalance TestFiles/Test4.java >> student_output.txt
java SymbolBalance TestFiles/Test5.java >> student_output.txt
java SymbolBalance TestFiles/Test6.java >> student_output.txt
java SymbolBalance TestFiles/MyTest1.java >> student_output.txt
java SymbolBalance TestFiles/MyTest2.java >> student_output.txt
java SymbolBalance TestFiles/MyTest3.java >> student_output.txt
java SymbolBalance TestFiles/MyTest4.java >> student_output.txt
java SymbolBalance TestFiles/MyTest5.java >> student_output.txt
java SymbolBalance TestFiles/MyTest6.java >> student_output.txt
java SymbolBalance TestFiles/MyTest7.java >> student_output.txt
java SymbolBalance TestFiles/MyTest8.java >> student_output.txt
java SymbolBalance TestFiles/MyTest9.java >> student_output.txt
java SymbolBalance TestFiles/MyTest10.java >> student_output.txt

python3 countDifferences.py
