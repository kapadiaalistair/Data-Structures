/* This tests whether []]]] comments are ignored */
public class MyTest2.java {

	/* I love Data Strucutures /* */

	public static void main(String[] args) {
		foo();
	}
}
