"this file tests whether everything inside a string is ignored
public class MyTest3 {

	/* This is a comment block inside a string */
	
	public static void main(String[] args) {
		foo(); foo()()(); []foo(); {}}{ foo();
		}
}"
