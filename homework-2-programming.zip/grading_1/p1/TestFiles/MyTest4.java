/* This file checks if symbol balances are carried over multiple lines */

public class MyTest4 {

	public static void main(String[] args) {
		String output = "This is the easiest test file to get correct";
		System.out.println(output);
		int[] array = null;
		{ What is this line? }
	}
}
