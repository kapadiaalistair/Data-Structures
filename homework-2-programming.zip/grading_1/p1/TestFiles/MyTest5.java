/* There should be a symbol mismatch after popping the stack */

public class MyTest5 {

	public static void main(String[] args) {

		int a = 5;
		int b = (a * 2) / 4;
		b *= 1;
		b /= 3;
		System.out.println("This program is not correct."];
	}
}
