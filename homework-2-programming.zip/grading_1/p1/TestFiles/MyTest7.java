/* The stack should not be empty at the end of the program
 *
 * public class MyTest7 {
 * 	public static void main (String[] args) {
 *
 * 		foo();  [[]test]]]];
 * 	}
 * }
 *
