def read_lines(filestring):

	output = None
	with open(filestring, "r") as filename:
		output = [line.strip().lower() for line in filename]

	return output

def main():

    # total number of points = 16
    points = 16

    # get the student's output
    student_lines = read_lines("student_output.txt")

    # get the actual output with and without brackets
    output_lines_1 = read_lines("actual_output.txt")
    output_lines_2 = read_lines("actual_output_with_brackets.txt")

    # get the with-and-without-brackets lengths
    length_1 = min(len(output_lines_1), len(student_lines))
    length_2 = min(len(output_lines_2), len(student_lines))

    # count mistakes if output is without brackets
    counter_1 = 0
    for i in range(length_1):
        if output_lines_1[i] != student_lines[i]:
            counter_1 += 1

    # count mistakes if output is with brackets
    counter_2 = 0
    for i in range(length_2):
        if output_lines_2[i] != student_lines[i]:
            counter_2 += 1

    # adjust counter depending on the difference if file sizes
    counter_1 += max(len(output_lines_1), len(student_lines)) - length_1
    counter_2 += max(len(output_lines_2), len(student_lines)) - length_2

    # determine the actual number of mistakes made
    counter = min(counter_1, counter_2)

    # print the output
    print("There are {} mistakes in the students output file".format(counter))
    print("Award the student {} points.".format(points - counter))


main()
