import java.util.*;
import java.io.*;

public class AutomationGrader {

	private static HashSet<String> errorLog = new HashSet<>();

	private static void checkIsEmpty(TwoStackQueue queue, boolean value) {
		if (queue.isEmpty() == value) {
			System.out.println("Check isEmpty(): OK");
		}
		else {
			String error = "Check isEmpty(): Fail";
			System.out.println(error);
			errorLog.add(error);
		}
	}

	private static void checkSize(TwoStackQueue queue, int size) {
		if (queue.size() == size) {
			System.out.println("Check size(): OK");
		}
		else {
			String error = "Check size(): Fail";
			System.out.println(error);
			errorLog.add(error);
		}
	}

	private static void checkEnqueueandDequeue(int value, int actualValue) {
		if (value == actualValue) {
			System.out.println("Check Enqueue and Dequeue: OK");
		}
		else {
			String error = "Check Enqueue and Dequeue: Fail (Either Enqueue, Dequeue or Both)";
			System.out.println(error);
			errorLog.add(error);
		}
	}

	private static void TestCase0(TwoStackQueue<Integer> integerQueue, int[] integerTestInputs) {

		checkIsEmpty(integerQueue, true);

		for (int i = 0; i < integerTestInputs.length; i ++)
			integerQueue.enqueue(integerTestInputs[i]);
		checkIsEmpty(integerQueue, false);

		for (int i = 0; i < integerTestInputs.length; i++) {
			int dequeuedValue = integerQueue.dequeue();
			checkEnqueueandDequeue(dequeuedValue, integerTestInputs[i]);
			checkSize(integerQueue, integerTestInputs.length - i - 1);
		}
		checkIsEmpty(integerQueue, true);

	}

	private static void TestCase1(TwoStackQueue<Integer> integerQueue, int[] integerTestInputs) {

		for (int i = 0; i < integerTestInputs.length; i ++) {
			integerQueue.enqueue(integerTestInputs[i]);
			checkSize(integerQueue, i + 1);
			checkIsEmpty(integerQueue, false);
		}

		for (int i = 0; i < integerTestInputs.length; i ++) {
			int dequeuedValue = integerQueue.dequeue();
			checkEnqueueandDequeue(dequeuedValue, integerTestInputs[i]);
			checkSize(integerQueue, integerTestInputs.length - i - 1);
			if (i != integerTestInputs.length - 1)
				checkIsEmpty(integerQueue, false);
		}
		checkIsEmpty(integerQueue, true);
	}

	private static void TestCase2(TwoStackQueue<Integer> integerQueue, int[] integerTestInputs) 
	throws Exception {

		integerQueue.enqueue(3);
		checkSize(integerQueue, 1);
		checkIsEmpty(integerQueue, false);
		checkEnqueueandDequeue(integerQueue.dequeue(), 3);

		try {
			if (integerQueue.dequeue() == null) {
				System.out.println("Null received on dequeuing an empty queue: OK");
			}

			else {
				String error = "Check Dequeue: Fail";
				errorLog.add(error);
				System.out.println(error);
			}
		}

		catch (Exception e) {
			System.out.println("Error thrown on dequeueing an empty queue: OK");
		}

	}

	private static void TestCase3() throws Exception {

		TwoStackQueue<Integer> newQueue = new TwoStackQueue<>();

		try {
			if (newQueue.dequeue() == null) {
				System.out.println("Null received on dequeuing an empty queue: OK");
			}

			else {
				String error = "Check Dequeue: Fail";
				errorLog.add(error);
				System.out.println(error);
			}
		}

		catch (Exception e) {
			System.out.println("Error thrown on dequeuing an empty queue: OK");
		}
	}

	private static void TestCase4(Scanner scan) {
		System.out.print("Does the user use instance variables from MyStack.java (y/n): ");
		String response = scan.nextLine();
		if (response.equals("n")) {
			System.out.println("Fail");
			String error = "MyStack variables not used";
			errorLog.add(error);
		}

	}

	private static void TestCase5(Scanner scan) {
		System.out.print("Are the enqueues made on Stack 1 (y/n): ");
		String response = scan.nextLine();
		if (response.equals("n")) {
			System.out.println("Fail");
			String error = "Enqueues not made on Stack 1";
			errorLog.add(error);

		}
	}
	
	private static void TestCase6(Scanner scan) {
		System.out.print("Are the dequeues made on Stack 2 (y/n): ");
		String response = scan.nextLine();
		if (response.equals("n")) {
			System.out.println("Fail");
			String error = "Dequeues not made on Stack 2";
			errorLog.add(error);
	
		}
	}
	
	private static void TestCase7(Scanner scan) {
		System.out.print("Does the student implement MyQueue.java (y/n): ");
		String response = scan.nextLine();
		if (response.equals("n")) {
			System.out.println("Fail");
			String error = "Doesn't implement MyQueue.java";
			errorLog.add(error);
		}
	}

	private static void printErrorLog() {
		System.out.println("For some reason, the automated grader crashed. Given below ");
		System.out.println("is the error log before the crash: ");

		for (String error : errorLog) {
			System.out.println(error);
		}
	}

	public static void main(String[] args) throws Exception {

		Scanner scan = new Scanner(System.in);
		int[] integerTestInputs = {-1, 0, 50, -74, 2, -100, 25};

		int points = 23; 
		// Test Case 1.a (Sequential Manipulation) 
		TwoStackQueue<Integer> integerQueue = new TwoStackQueue<>();
		TestCase0(integerQueue, integerTestInputs);

		// Test Case 1.b (Alternate Manipulation)
		TestCase1(integerQueue, integerTestInputs);

		// Test Case 1.c (Dequeue an empty queue after work is performed)
		TestCase2(integerQueue, integerTestInputs);

		// Test Case 1.d (Dequeue an empty queue without doing work)
		TestCase3();


		try {

			BufferedReader br = new BufferedReader(new FileReader("TwoStackQueue.java"));
			String line;
			System.out.println("*************************************************************************************************************************");
			while((line = br.readLine()) != null) { 
				System.out.println(line);
			}
			System.out.println("*************************************************************************************************************************");

			// Test Case 3 - 6
			TestCase4(scan);
			TestCase5(scan);
			TestCase6(scan);
			TestCase7(scan);

			// Test Case 7
			BufferedReader newbr = new BufferedReader(new FileReader("Problem2.txt"));
			System.out.println("*************************************************************************************************************************");
			while((line = newbr.readLine()) != null) { 
				System.out.println(line);
			}
			System.out.println("*************************************************************************************************************************");

			System.out.println("Is the runtime analysis correct (y/n): ");
			String response = scan.next();
			if (response.equals("n")) {
				System.out.println("Fail");
				String error = "Incorrect Runtimes for Enqueue / Dequeue";
				errorLog.add(error);
			}

			System.out.println("*************************************************************************************************************************");
			System.out.println("\nGiven below is the error log:\n");
			for (String error : errorLog) {
				System.out.println(error);
			}

			System.out.println("How many points to deduct?: " );
			int deductions = scan.nextInt();
			System.out.println(String.format("AWARD THE CANDIDATE %d POINTS FOR Problem2.java and TwoStackQueue.java", points - deductions));
		}

		catch (Exception e) {
			System.out.println(e);
			printErrorLog();
		}
	}
}
