/* Following the specification in the README.md file, provide your 
 * FileAvl class.
 */
import java.io.File; 
import java.io.FileNotFoundException; 
import java.util.*;
public class FileAvl 
{
    Scanner sc;
    AvlTree tree = new AvlTree();
    public FileAvl(String filename) throws FileNotFoundException
    {
        File file = new File(filename);
        sc = new Scanner(file);
        //sc = new Scanner(arbitrary);
        constructtree(sc);
    }
    private void constructtree(Scanner sc)
    {
        int linecounter = 1;
        while(sc.hasNextLine())
        {
            Scanner sc2 = new Scanner(sc.nextLine());
            while(sc2.hasNext())
            {
                indexWord(sc2.next(), linecounter);
            }
            linecounter++;
        }
    }
    public void indexWord(String word, int line)
    {
       tree.insert(word.toLowerCase(), line);
        
    }
    public List<Integer> getLinesForWord(String word)
    {
        return tree.getLinesForWord(word);
    }
    public void printIndex()
    {
        tree.printIndex();
    }
    public void printTree()
    {
        tree.printTree();
    }
}

