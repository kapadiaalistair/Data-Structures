/* Following the specification in the README.md file, provide your 
 * Problem1 class.
 */
import java.util.*;
public class Problem1
{
    public static void main(String[] args)
    {
        ExpressionTree a = new ExpressionTree("2 * 3 1 * + 9 -");
        System.out.println(a.infix());
        
        /*Scanner a = new Scanner("2 3 1 * + 9 -");
        while(a.hasNext())
        {
            if(a.hasNextInt())
            {
                System.out.println("int: " + a.next());
            }
            else
            {
                System.out.println(a.next());
            }
        }*/
    }
}