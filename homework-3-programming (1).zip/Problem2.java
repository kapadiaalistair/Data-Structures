/* Following the specification in the README.md file, provide your 
 * Problem2 class.
 */
import java.io.FileNotFoundException; 
import java.io.File; 

public class Problem2
{
    public static void main(String[] args) throws FileNotFoundException
    {
        FileAvl bc = new FileAvl(args[0]);
        bc.printIndex();
    }
    
}