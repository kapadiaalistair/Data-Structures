# Student README file

For problem 1, all functions as expected. If the input is invalid, a generic error message returned and the program is ended.

Problem 2, all functions as expected. 