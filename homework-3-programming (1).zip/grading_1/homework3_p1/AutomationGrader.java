import java.util.*;
import java.io.*;

public class AutomationGrader {

	static HashSet<String> errorLog = new HashSet<>();
	static Scanner scanner = new Scanner(System.in);

	final static String[] TESTCASES = {"4", 
					   "4 10 *", 
					   "2 3 + 8 4 / *", 
					   "2 3 1 - + 8 4 / *",
					   "3 2 - 5",
					   "2 *"};

	// solutions is in the form {eval, postfix, prefix}
	// need to manually check infix
	// if subarray is empty, means that the postfix expression isn't valid
	final static String[][] SOLUTIONS = {{"4", "4", "4"}, 
					     {"40", "4 10 *", "* 4 10"}, 
					     {"10", "2 3 + 8 4 / *", "* + 2 3 / 8 4"}, 
					     {"8", "2 3 1 - + 8 4 / *", "* + 2 - 3 1 / 8 4"},
					     {},
					     {}};
	static int i = 0;
	static int testCaseCount = 1;
	static int locOfError = -1;

	static void printSuccess(String type) {
		System.out.println(type + " - TestCase " + testCaseCount + ": OK");
	}

	static void printError() {
		System.out.println("TestCase " + testCaseCount + ": FAIL");
	}

	static void Assert(int result, int expected) {
		
		if (result == expected)
			printSuccess("eval()");

		else {
			printError();
			System.out.println("Student's eval(): " + result);
			System.out.println("Correct eval(): " + expected);
			String error = "eval() - TestCase " + testCaseCount + ": FAIL";
			errorLog.add(error);
		}
	}

	static void Assert(String type, String result, String expected) {
	
		result = result.trim();
		if (result.equals(expected))
			printSuccess(type);

		else {
			printError();
			System.out.println("Student's " + type + ": " + result);
			System.out.println("Correct " + type + ": " + expected);
			String error = type + " - TestCase " + testCaseCount + ": FAIL";
			errorLog.add(error);
		}
	}

	static void checkTestCase(String testCase, int eval, String postfix, String prefix, int startFrom) throws Exception{

		ExpressionTree tree = new ExpressionTree(testCase);
		locOfError++;

		if (startFrom < 0) {
			// check eval()
			Assert(tree.eval(), eval);
		}
		locOfError++;

		if (startFrom < 1) {
			// check postfix()
			Assert("postfix()", tree.postfix(), postfix);
		}
		locOfError++;

		if (startFrom < 2) {
			// check prefix()
			Assert("prefix()", tree.prefix(), prefix);
		}
		locOfError++;

		if (startFrom < 3) {
			// manually check infix
			String infix = tree.infix();
			System.out.print("Is this the correct infix (y/n)-   " + infix + "  : ");
			String response = scanner.nextLine();
			if (response.equals("y"))
				printSuccess("infix()");
			else {
				printError();
				String error = "infix() - TestCase " + testCaseCount + ": FAIL"; 
				errorLog.add(error);
			}
		}

	}

	static void checkBadTestCase(String testCase) throws Exception {

		try {
			ExpressionTree tree = new ExpressionTree(testCase);
			
			System.out.print("Did student print a message acknowledging the invalid expression (y/n): ");
			String response = scanner.nextLine();

			if (response.equals("n")) {
				String error = "TestCase " + testCaseCount + ": Error NOT thrown on invalid postfix";
				errorLog.add(error);
			}
		}

		catch (Exception e) {
			printSuccess("Bad Test Case");
		}
	}

	static void runTestCases() throws Exception {

		int startFrom = -1;

		for (; i < TESTCASES.length; i ++) {

			if (SOLUTIONS[i].length == 0) {
				checkBadTestCase(TESTCASES[i]);
			}


			else {
				String testCase = TESTCASES[i];
				int eval = Integer.parseInt(SOLUTIONS[i][0]);
				String postfix = SOLUTIONS[i][1];
				String prefix = SOLUTIONS[i][2];

				try {
					checkTestCase(testCase, eval, postfix, prefix, startFrom);
					locOfError = -1;
				}

				catch (Exception e) {
					printError();
					String error = "";
					if (locOfError == -1) {
						error = "TestCase " + testCaseCount + ": Construction threw an error";
						testCaseCount ++;
						i ++;
						locOfError = -1;
					}

					else if (locOfError == 0)
						error = "TestCase " + testCaseCount + ": eval() threw an error";

					else if (locOfError == 1)
						error = "TestCase " + testCaseCount + ": postfix() threw an error";

					else if (locOfError == 2)
						error = "TestCase" + testCaseCount + ": prefix() threw an error";

					else if (locOfError == 3) {
						error = "TestCase" + testCaseCount + ": infix() threw an error";
						testCaseCount ++;
						i ++;
						locOfError = -1;
					}

					else
						locOfError = -1;

					errorLog.add(error);
					testCaseCount --;
					i --;
				}
			}

			testCaseCount++;
			System.out.println("\n");
			startFrom = locOfError;
			locOfError = -1;

		}
	}

	static boolean printFile(String fileName) throws IOException {

		try {
			BufferedReader br = new BufferedReader(new FileReader("ExpressionTree.java"));
			String line;
			System.out.println("*****************************************************************************************************************************************");

			while ((line = br.readLine()) != null)
				System.out.println(line);

			System.out.println("*****************************************************************************************************************************************");
			return true;
		}

		catch (FileNotFoundException e) {
			String error = "Program code not found";
			System.out.println(error);
			errorLog.add(error);
			return false;
		}
	}

	static void printErrorLog() {

		if (errorLog.size() > 0)
			System.out.println("Given below is the Error Log:");

		else 
			System.out.println("The student has no errors!");

		for (String error : errorLog) {
			System.out.println(error);
		}
	}

	static void checkResponse(String response, String toAdd) {

		if (response.equals("n")) {
			System.out.println("TestCase: FAIL");
			errorLog.add(toAdd);
		}

		if (response.equals("y")) {
			System.out.println("TestCase: OK");
		}
	}

	public static void main(String[] args) throws Exception {

		// test on the predefined test cases
		runTestCases();

		// print program code
		if (printFile("ExpressionTree.java")) {

			// ask questions
			System.out.print("Does the student construct the ExpressionTree in the constructor? (y/n): ");
			checkResponse(scanner.nextLine(), "ExpressionTree not constructed in constructor.");

			System.out.print("Is the ExpressionNode class a nexted class? (y/n): ");
			checkResponse(scanner.nextLine(), "ExpressionNode is not a nested class");

			System.out.print("Is the tree constructed using a stack-based algorithm? (y/n): ");
			checkResponse(scanner.nextLine(), "No stack-based algorithm used");
		}

		System.out.println("\n\n");
		printErrorLog();
	}
}
