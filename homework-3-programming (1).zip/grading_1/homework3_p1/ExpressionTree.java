/* Following the specification in the README.md file, provide your 
 * ExpressionTree class.
 */
import java.util.*;
public class ExpressionTree {
        class ExpressionNode
        {
            String starter;
            ExpressionNode left;
            ExpressionNode right;
            ExpressionNode(String in)
            {
                starter = in;
                left=right=null;
            }
        }
        private String input;
        private ExpressionNode root;
        /* Your constructor should take in a string containing the postfix expression that you
         * are using to build your expression tree. */
        
        public ExpressionTree(String expression) {
            LinkedList<ExpressionNode> builder = new LinkedList<ExpressionNode>();    
            Scanner a = new Scanner(expression);
            while(a.hasNext())
            {
                if(a.hasNextInt())
                {
                    
                    ExpressionNode operand = new ExpressionNode(a.next());
                    builder.push(operand);
                }
                else
                {
                    try{
                        ExpressionNode operator = new ExpressionNode(a.next());
                        operator.right = builder.pop();
                        operator.left = builder.pop();
                        builder.push(operator);
                    }
                    catch(Exception e)
                    {
                        System.out.println("ERROR: INVALID INPUT");
                    }
                }
            }
            root=builder.pop();
            if(builder.peek()!=null)
            {
                System.out.println("ERROR: INVALID INPUT");
            }
                   
        }
    
    
         /* This is the PUBLIC interface to the class. */
        public int eval(){
            return eval(root);
        }
        private int eval(ExpressionNode root)
        {
            if(root.starter.equals("*"))
            {
                return (eval(root.left)*eval(root.right));
            }
            else if(root.starter.equals("/"))
            {
                return (eval(root.left)/eval(root.right));
            }
            else if(root.starter.equals("+"))
            {
                return (eval(root.left)+eval(root.right));
            }
            else if(root.starter.equals("-"))
            {
                return (eval(root.left)-eval(root.right));
            }
            else
            {
                
                return Integer.parseInt(root.starter);
            }
        }
        private String post = "";
        public String postfix() {
            return postfix(root);            
        }
        public String postfix(ExpressionNode c)
        {
            if(c.left!=null && c.right!=null)
            {
                return postfix(c.left) + " " + postfix(c.right) + " " + c.starter;
            }
            else if(c.left!=null)
            {
                return postfix(c.left) + " " + c.starter+ " ";
            }
            else if(c.right!=null)
            {
                return postfix(c.right) + " " + c.starter+ " ";
            }
            else
            {
                return c.starter;
            }
        }
        
        public String prefix() {
            return prefix(root);            
        }
        private String prefix(ExpressionNode c)
        {
            if(c.left!=null && c.right!=null)
            {
                return c.starter + " " + prefix(c.left) + " " + prefix(c.right) ;
            }
            else if(c.left!=null)
            {
                return c.starter + " " + prefix(c.left) + " ";
            }
            else if(c.right!=null)
            {
                return c.starter + " " + prefix(c.right) + " ";
            }
            else
            {
                return c.starter;
            }
           
        }

        public String infix() {
            return infix(root);
              /* Fill in code here. */
            
        }
        private String infix(ExpressionNode c)
        {
            if(c.left!=null && c.right!=null)
            {
                return  "(" + infix(c.left) + " " + c.starter + " " + infix(c.right) + ")";
            }
            else if(c.left!=null)
            {
                return infix(c.left) + " " + c.starter + " ";
            }
            else if(c.right!=null)
            {
                return c.starter + " " + infix(c.right) + " ";
            }
            else
            {
                return c.starter;
            }
           
        }
    
    
         /* You will need to provide the private, recursive versions of these methods, 
          * the instance variable(s), and any static nested class that you might need below */
     
}
