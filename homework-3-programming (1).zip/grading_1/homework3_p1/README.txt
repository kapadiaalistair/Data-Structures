This file contains the high level description of the automated script to 
grade Programming Project 1 for the Data Structures Homework #3
------------------------------------------------------------------------
------------------------------------------------------------------------

##########################
Author: Ishaan Agrawal
Date: November 2017
Last Update: November 2017
##########################

How to Use the Tester:
----------------------

1. Run Arunahva's / Jessie's script to unzip most folders

2. Place the Makefile, copyScript.txt file and AutomatioGrader.java script
file in the directory that contains all student unzipped submissions.

3. Run script "copyScripts"  by typing "sh copyScript.txt" to move the Makefile and Script into all student
submission directiories.

4. For each student:
	a. Call make
	b. Run their provided tester
	c. Run the automation tester
	d. Follow the instructions displayed by the automation script
	e. Add the points from their tester and our tester to get the final
	   score



Test Cases
----------

Since the data structure to be tested is a binary expression tree, we will be
evaluating the methods vital to the correct functioning of the expression
tree.

Methods to Test:

1. postfix()
2. prefix()
3. infix()
4. eval()


Test Case 1: Run their Problem1.java file

Test Case 2: Integer Stack
	a. Test Case 1.a. (Sequential Manipulation) 
		i. Check isEmpty() == true
		ii. Enqueue all
		iii. calculate size()
		iv Check isEmpty() == false
		v. Dequeue all
		vi. Calculate size()
		vii. Check isEmpty() == true

	b. Test Case 1.b (Alternate Manipulation)
		i. Check isEmpty() == true
		ii. Enqueue one
		iii. Check size()
		v. Check isEmpty == false
		iv. Continue ii. to v. until all are enqueued
		v. Dequeue one
		vi. Check size()
		vii. Check isEmpty() == false
		viii. Continue till all elements are dequeued
		ix. Check isEmpty() == true

	c. Test Case 1.c (Dequeue an Empty Queue after work is performed)
		i. Check isEmpty() == true
		ii. Enqueue and Dequeue a test variable 
		iii. Pop the empty stack
			Should return NULL or throw an error

	d. Test Case 1.d
		i. Create a queue and deuqueue it
			Should return NULL or throw an error

Test Case 3: Intance variables of MyStack.java class
	a. Print lines that contain MyStack
	b. (Manually assign points) - Scanner

Test Case 4: Enqueues are made on Stack 1
	a. Store the stack names in variables
	b. Print out the entire java file
	c. Ask user if enqueues are made on stack 1 


Test Case 5: Dequeues are made on Stack 2
	a. Store the stack names in variables
	b. Print out the entire java file
	c. Ask user if dequeues are made on stack 2 

Test Case 6: Implements MyQueue.java
	a. Read through the java file
	b. Put the contents in a String
	c. Check if it contains "implements MyQueue"
	d. Return result and print result


Test Case 7: Analysis of Runtimes for Enqueue and Dequeue in Problem2.txt
	a. Print out the entire Problem2.txt
	b. Ask user if analysis is correct

