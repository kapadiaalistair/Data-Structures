import java.util.*;
import java.io.*;

public class AutomationGrader {

	private static Scanner scanner = new Scanner(System.in);
	private static HashSet<String> errorLog = new HashSet<>();

    	static void printSuccess(String testCase) {
        	System.out.println(testCase + ": OK");
   	 }

    	static void printFail(String testCase) {
        	System.out.println(testCase + ": FAIL");
    	}

	private static void TestCase2() throws Exception {
		
		String[] arr = {"testing","random","string", "generators", "should", "definitely", "be", "a", "thing", "inJava" };
         	int[] arr2 = {1, 34, 23, 78, 99, 13, 11, 70, 475, 666};

         	for(int i = 1; i <= arr.length; i++) {
         	
			try {
		        	FileAvl tester = new FileAvl("TestFiles/EmptyFile.txt");
		        	tester.indexWord(arr[i - 1], arr2[i - 1]);
		        	int gotLine = (int) tester.getLinesForWord(arr[i - 1].toLowerCase()).get(0);
		        	if (gotLine == arr2[i - 1]) {
		            		printSuccess("Case 2: indexWord() and getLinesforWord()");
		        	}
				else if(tester.getLinesForWord(arr[i - 1]).size() != 1) {
		        		printFail("Case 2: Expected exactly one occurence but got " + tester.getLinesForWord(arr[i - 1]).size()+" occurences.");
		        		errorLog.add("Case 2: Incorrect indexWord() and getLinesforWord()");
		        	}
				else {
		            		printFail("Case 2: indexWord() and getLinesforWord() Expected line #"+arr2[i - 1]+" but got line #"+gotLine);
		            		errorLog.add("Case 2: Incorrect indexWord() and getLinesforWord()");
		        	}
			}
		
			catch (Exception e) {
				printFail("Case 2: Exception caught. Likely FileAvl creation failed. More info: " + e);
				errorLog.add("Case 2: Exception caught.");
			}
         	}
	}

	private static void TestCase3 () throws Exception {
		
		String[] testStrings = {":::he:llo,", "wor:&#$ld!", "!!JAVA???", ",Data,", ",...S#t$ructure.", ")))th$isIsAL*ongW(ord!",
			"@n#i%c#e.", "t...o", "me..et", "@@you!!!"};
		
		int[] testStringLineNumbers = {-20, 10, 9, 666, -233, 2, 7, -8, 20, -1};

        	for (int i = 1; i <= 10; i++) {


            		try {
                		FileAvl testFileAvl = new FileAvl("TestFiles/EmptyFile.txt");
                		testFileAvl.indexWord(testStrings[i - 1], testStringLineNumbers[i - 1]);
                		if ((int) testFileAvl.getLinesForWord(testStrings[i - 1].toLowerCase()).get(0) == testStringLineNumbers[i - 1]) {
                    			printSuccess("Case 3 test " + i + ": indexWord() and getLinesforWord() - " + i);
                		}

                		else {
					System.out.println(testFileAvl.getLinesForWord(testStrings[i].toLowerCase()));
                			printFail("indexWord() and getLinesforWord() - " + i);
                			errorLog.add("Incorrect indexWord() and getLinesforWord()");
                		}
            		}

			catch (Exception e) {
				printFail("indexWord() and getLinesforWord() - " + i);
                		errorLog.add("Incorrect indexWord() and getLinesforWord()");
			}

            	}
        }

	private static void TestCase4() throws Exception {

        	String[] strArray = {"This", "is", "a", "senTence", "that", "Is", "used","to", "test", "stuff"};
        	int[] intArray = {2,3, 7, 9, 20, 22, 67,89, 123, 4};


        	for(int i = 1; i <= 10; i++) {
            		try {
                		FileAvl testFileAvl = new FileAvl("TestFiles/TestFile" + i + ".txt");
                		testFileAvl.indexWord(strArray[i - 1], intArray[i - 1]);
                		List<Integer> returnedLineNumber = testFileAvl.getLinesForWord(strArray[i - 1].toLowerCase());
                		if (returnedLineNumber.contains(intArray[i - 1])) {
                    			printSuccess("Case 4 test " + i + ": indexWord() and getLinesforWord()");
                		}

               			 else {
                    			printFail("indexWord() and getLinesforWord(). Case 4 expected [" + intArray[i - 1] + "] but got " + returnedLineNumber);
                    			errorLog.add("Incorrect indexWord() and getLinesforWord()");
                		}
            		}
            		catch (Exception e) {
                		printFail("Exception on Case 4 test " + i + ": indexWord() and getLinesforWord()");
                		errorLog.add("Incorrect indexWord() and getLinesforWord()");
            		}
            
        	}
	}

	private static void TestCase5() throws Exception {


        	String[] strArray = {"---this", "is__", "$%&a%$#@", "///sen-tence&^*%$#", "./tha#@!t/", "%is%", ".used*","/for", "testing/", "!"};
        	int[] intArray = {2,3, 7, 9, 20, 22, 67, 89, 0, 4};


        	for(int i = 1; i <= 10; i++) {
            		try {
                		FileAvl testFileAvl = new FileAvl("TestFiles/TestFile" + i + ".txt");
                		testFileAvl.indexWord(strArray[i - 1], intArray[i - 1]);
                		List<Integer> returnedLineNumber = testFileAvl.getLinesForWord(strArray[i - 1].toLowerCase());
                		if(returnedLineNumber.contains(intArray[i - 1])) {
                    			printSuccess("Case 5 test " + i + ": indexWord() and getLinesforWord()");
                		}
                		else {
                    			printFail("indexWord() and getLinesforWord(). Case 5 expected [" + intArray[i - 1] + "] but got " + returnedLineNumber);
                    			errorLog.add("Incorrect indexWord() and getLinesforWord()");
                		}
            		}
            		
			catch(Exception e) {
                		printFail("Exception on Case 5 test " + i + ": indexWord() and getLinesforWord()");
                		errorLog.add("Incorrect indexWord() and getLinesforWord()");
            		}

        	}
	}
	
	private static void TestCase6() throws Exception {
		
		String myString = "nuneke";
        	int lineNo = 35;

		try {
        		FileAvl myFileAvl = new FileAvl("TestFiles/EmptyFile.txt");
        		myFileAvl.indexWord(myString, lineNo);
        		myFileAvl.indexWord(myString, lineNo);
        
			if (myFileAvl.getLinesForWord(myString).size() > 1) {
        			printFail("No Duplicate Lines");
				String error = "Duplicate Line Numbers for the Same Word";
            			errorLog.add(error);
        		}
        		else {
        			printSuccess("No Duplicate Lines");
    			}
		}

		catch (Exception e) {
			printFail("No Duplicate Lines");
			String error = "Duplicate Line Numbers for the Same Word";
			errorLog.add(error);
		}
	}
	
	private static void TestCase7() throws Exception {

		String myString = "::,,nu?ne--ke!";
        	int lineNo = -3;

		try {
        		FileAvl myFileAvl = new FileAvl("TestFiles/EmptyFile.txt");
        		myFileAvl.indexWord(myString, lineNo);
        		myFileAvl.indexWord(myString, lineNo);
        
			if (myFileAvl.getLinesForWord(myString).size() > 1) {
        			printFail("No Duplicate Lines");
				String error = "Duplicate Line Numbers for the Same Word";
            			errorLog.add(error);
        		}
        		else {
        			printSuccess("No Duplicate Lines");
    			}
		}

		catch (Exception e) {
			printFail("No Duplicate Lines");
			String error = "Duplicate Line Numbers for the Same Word";
			errorLog.add(error);
		}

	}

	private static void TestCase8(Scanner scan) {
		System.out.print("Is an AVL Tree an instance on the FileAVL object? (y/n): ");
		String response = scan.nextLine();
		if (response.equals("n")) {
			printFail("AVL Instance for FileAVL object");
			String error = "Dequeues not made on Stack 2";
			errorLog.add(error);
		}
		else {
			printSuccess("AVL Instance for FileAVL object");
		}
	}


	private static void TestCase9(Scanner scan) {
		System.out.print("Are indexWord() and getLinesforWord() interacting with the AVLTree object? (y/n): ");
		String response = scan.nextLine();
		if (response.equals("n")) {
			printFail("indexWord() and getLinesForWord() not interacting with the AVLTree");
			String error = "Dequeues not made on Stack 2";
			errorLog.add(error);
		}
		else {
			printSuccess("indexWord() and getLinesForWord() not interacting with the AVLTree");
		}
	}

	private static void printErrorLog() {
		System.out.println("For some reason, the automated grader crashed. Given below ");
		System.out.println("is the error log before the crash: ");

		for (String error : errorLog) {
			System.out.println(error);
		}
	}


	public static void main(String[] args) throws Exception {

		Scanner scan = new Scanner(System.in);
		int points = 20; 

		TestCase2();
		TestCase3();
		TestCase4();
		TestCase5();
		TestCase6();
		TestCase7();


		try {

			BufferedReader br = new BufferedReader(new FileReader("FileAvl.java"));
			String line;
			System.out.println("*************************************************************************************************************************");
			while((line = br.readLine()) != null) { 
				System.out.println(line);
			}
			System.out.println("*************************************************************************************************************************");

			TestCase8(scan);
			TestCase9(scan);

			System.out.println("The grading script is now done judging the FileAvl.java object.");
			System.out.println("Given below is the error log for this submission");
			for (String error : errorLog) {
				System.out.println(error);
			}
			System.out.println();
			System.out.println("Subtract the required points from 20 total.");
			System.out.println("Remember to test the student's Problem2.java submission.");
		}

		catch (Exception e) {
			System.out.println(e);
			printErrorLog();
		}

		
	}
}
