This file contains the high level description of the automated script to 
grade Programming Project 2 for the Data Structures Homework #3
------------------------------------------------------------------------
------------------------------------------------------------------------

##########################
Author: Ishaan Agrawal
Date: November 2018
Last Update: November 2018
##########################

How to Use the Tester:
----------------------

1. Place the Makefile and AutomatioGrader.java script
file in the directory that contains all student unzipped submissions.

2. For each student:
	a. Call make
	b. Run their provided tester
	c. Run the automation tester
	d. Follow the instructions displayed by the automation script
	e. Add the points from their tester and our tester to get the final
	   score


Test Cases
----------

Since the data structures to be tested are a FileAVL object and an AVL Tree, we will be
evaluating the methods vital to the correct functioning of the expression
tree.

Methods to Test:

1. constructor
2. indexWord()
3. getLinesForWord()
4. printIndex()


Test Case 1: Various Test Files to Test printIndex()
	a. TestFile1.txt
	b. TestFile2.txt
	c. TestFile3.txt
	d. TestFile4.txt
	e. TestFile5.txt
	f. TestFile6.txt
	g. TestFile7.txt
	h. TestFile8.txt
	i. TestFile9.txt
	j. TestFile10.txt

Test Case 2: Test the indexWord() and getLinesforWord() functions
	a. Start with a FileAVL constructured on an empty file.
	b. Add a word without punctuation using indexWord()
	c. Retrieve the added result using getLinesforWord() on the same word.
	d. Repeat a - c 10 times

Test Case 3: Test the indexWord() and getLinesforWord() functions
	a. Start with a FileAVL constructured on an empty file.
	b. Add a word with punctuation using indexWord()
	c. Retrieve the added result using getLinesforWord() on the same word.
	d. Repeat a - c 10 times

Test Case 4: Test the indexWord() and getLinesforWord() functions
	a. Start with a FileAVL on TestFile<X>.txt
	b. Add a word without punctuation using indexWord()
	c. Retrieve the added result using getLinesforWord() on the same word.
	d. Repeat a - c 10 times on different values for <X>.

Test Case 5: Test the indexWord() and getLinesforWord() functions
	a. Start with a FileAVL on TestFile<X>.txt
	b. Add a word with puntuation using indexWord()
	c. Retrieve the added result using getLinesforWord() on the same word.
	d. Repeat a - c 10 times on different values for <X>.

Test Case 6: Test the indexWord() and getLinesforWord() functions
	a. Start with a FileAVL contructed on an empty file.
	b. Add a word and a specific line number using indexWord()
	c. Repeat step b on the same word and line number
	d. Check if getLinesforWord() doesn't return the duplicate line number

Test Case 7: Test the indexWord() and getLinesforWord() functions
	a. Start with a FileAVL constructured on a random TestFile<X>.txt file
	b. Add a word and a specific line number using indexWord()
	c. Repeat step b on the same word and line number
	d. Check if getLinesforWord() doesn't return the duplicate line number


Test Case 8: The AVLTree is an instance variable to the FileAVL object

Test Case 9: Manual inspection of indexWord() and getLinesforWord() to see if
they interact with an AVL instance.

Test Case 10: Run their Problem2.java file
