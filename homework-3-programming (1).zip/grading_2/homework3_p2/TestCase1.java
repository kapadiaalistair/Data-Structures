public class TestCase1 {

	public static void main(String[] args) throws Exception {

		for (int i = 1; i <= 10; i ++) {
			String filename = "TestFiles/TestFile" + i + ".txt";
			FileAvl myAVL = new FileAvl(filename);
			myAVL.printIndex();
			System.out.println("\n");
		}
	}

}
