java TestCase1 > student_output.txt
