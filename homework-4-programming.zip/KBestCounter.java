import java.util.PriorityQueue;
import java.util.*;
import java.io.*;

public class KBestCounter<T extends Comparable<? super T>> implements KBest<T> {

    PriorityQueue<T> heap;
    int k;

    public KBestCounter(int k) {
        heap = new PriorityQueue <T>();
        this.k=k;
    }

    public void count(T x) {
        if(heap.size()<k)
        {
            heap.add(x);
        }
        //maintain size of heap and ensure it is never greater than k
        else if((x.compareTo(heap.peek()) > 0) && heap.size() == k)
        {
            heap.remove();
            heap.add(x);
        }
    }

    public List<T> kbest() {
        List<T> sorted = new ArrayList<T>();
        int size = heap.size();
        
        
        //populates list to return
        for(int x = 0; x<size; x++)
        {
            sorted.add(0,heap.poll());
        }
        
        //reconstructs heap
        for(int k = 0; k<sorted.size();k++)
        {
            heap.add(sorted.get(k));
        }
        return sorted;                  
    }
}
