# Student README file

All files are prepared according to the README. A class called Problem1.java was created as instructed as well. 