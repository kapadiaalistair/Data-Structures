/* Following the specification in the README.md file, provide your 
 * SpellChecker class.
 */
import java.util.*;
import java.io.*;

public class SpellChecker{
    File dict;
    
    Hashtable<String,String> fulldict;
    
    public SpellChecker(String dictionary) throws FileNotFoundException
    {
        dict = new File(dictionary);
        Scanner sc = new Scanner(dict);
        String temp;
        fulldict = new Hashtable<String,String>();
        while(sc.hasNext())
        {
            temp = sc.next();
            temp = temp.toLowerCase();
            fulldict.put(temp,temp);
        }
    }
    public List<String> getIncorrectWords(String filename) throws FileNotFoundException
    {
        List<String> incorrectWords = new ArrayList<String>();
        File input = new File(filename);
        String word;
        Scanner sc = new Scanner(input);
        while(sc.hasNext())
        {
            word = sc.next();
            word = word.toLowerCase();
            //first makes input lowercase and strips of punctation at the beginning and end of the input
            if(!Character.isLetterOrDigit(word.charAt(0)))
            {
                word = word.substring(1);
            }
            if(!Character.isLetterOrDigit(word.charAt(word.length()-1)))
            {
                word = word.substring(0,word.length()-1);
            }
            if(!fulldict.containsKey(word))
            {
                incorrectWords.add(word);
            }
        }
        return incorrectWords;       
    }
    
    public List<String> getSuggestions(String word)
    {
        List<String> suggestions = new ArrayList<String>();
        String tempadd;
        String tempremove;
        String tempexchange;
        Character tempchar;
        //created an array of characters to add, including an apostrophe 
        char[] additions = "abcdefghijklmnopqrstuvwxyz1234567890'".toCharArray();
        //cycle through each possible 'addition' and compare it to the dictionary
        for(char addon : additions)
        {
            for(int x = 0; x<=word.length(); x++)
            {
                tempadd = word.substring(0,x) + addon + word.substring(x,word.length());
                if(fulldict.containsKey(tempadd) && !suggestions.contains(tempadd))
                {
                    suggestions.add(tempadd);
                }
            }
        }
        //remove one letter at a time comparing it to the dictionary in between
        for(int x = 0; x < word.length(); x++)
        {
            tempremove = word.substring(0, x) + word.substring(x+1);
            if(fulldict.containsKey(tempremove) && !suggestions.contains(tempremove))
            {
                suggestions.add(tempremove);
            }
            //simultaneously exchange consecutive letters and compare it to dictionary
            if(x!= word.length()-1)
            {
                tempchar = word.charAt(x);
                tempexchange = word.substring(0,x) + word.charAt(x+1) + word.substring(x+1,word.length()); 
                tempexchange = tempexchange.substring(0,x+1) + tempchar + tempexchange.substring(x+2,word.length());
                if(fulldict.containsKey(tempexchange) && !suggestions.contains(tempexchange))
                {
                    suggestions.add(tempexchange);
                }
            }
             
        }        
        return suggestions;
    }
}